INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('1', 'c#设计', '欧阳耗子', '2405', '1-17', '1', '1', '', '57201921');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('2', '嵌入式', '肖贺', '物联网实验室', '3-17', '2', '2', '', '57201921');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('3', '图像处理', '罗勇', '物联网实验室', '3-17', '3', '3', '', '57201921');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('4', 'c#设计', '欧阳耗子', '2405', '1-17', '4', '4', '', '57201921');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('5', '图像处理', '罗勇', '物联网实验室', '1-17', '5', '2', '', '1234567');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('6', 'c#设计', '欧阳耗子', '2405', '1-17', '6', '3', '', '1234567');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('7', '图像处理', '罗勇', '物联网实验室', '1-17', '7', '1', '', '57201921');
INSERT INTO `classes` (`id`, `subject`, `teacher`, `room`, `weekstar_end`, `week`, `num`, `tecode`, `classcode`) VALUES ('8', 'C语言', '老九', '2134', '1-17', '1', '1', '1234567', '1234567');
