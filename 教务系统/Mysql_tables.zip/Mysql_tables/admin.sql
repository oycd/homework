INSERT INTO `admin` (`code`, `name`, `pwd`, `role`, `pic`, `dpm`, `major`, `class`, `classcode`) VALUES ('1234567', '张三', '123456', '老师', 'pic3.png', '软件工程学院', 'C语言', '软开1班', '0');
INSERT INTO `admin` (`code`, `name`, `pwd`, `role`, `pic`, `dpm`, `major`, `class`, `classcode`) VALUES ('123456789', '老九', '123456', '学生', 'pic2.png', '软件工程学院', '软件开发', '19软件软开1班', '1234567');
INSERT INTO `admin` (`code`, `name`, `pwd`, `role`, `pic`, `dpm`, `major`, `class`, `classcode`) VALUES ('5720192121', '欧阳存德', '192121', '学生', 'pic1.png', '软件工程学院', '软件工程(智能科学与技术)', '19软件智科1班', '57201921');
